Zopper Business Intelligence Internship Assignment
Author: Priya Rathore

Project Overview:
This project simulates car insurance policy sales and claims data using Python.

Datasets Generated:
policy_sales_data.csv
claims_data.csv

Tools Used:
Python (Pandas, NumPy)
Power BI Dashboard

Dashboard Features:
Total claim cost
Total premium collected
Monthly claim trend
Claim cost by policy tenure
Premium by policy tenure