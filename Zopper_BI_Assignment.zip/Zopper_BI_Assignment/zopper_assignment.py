
"""
Zopper Business Intelligence Internship Assignment
Author: Priya Rathore

Project Overview:
This project simulates car insurance policy data and claims data using Python.

Tools Used:
- Python (Pandas, NumPy)
- Power BI for dashboard visualization

Interactive Dashboard:
Power BI Workspace Link:
https://app.powerbi.com/links/ug6ZVZReh0?ctid=1fd9e355-fcd6-4193-920e-b13c4c6100b5&pbi_source=linkShare

Dashboard Preview:
See dashboard_preview.png in this project folder.
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta

n = 1000000

customer_id = np.arange(1, n+1)
vehicle_id = np.arange(1, n+1)

vehicle_value = 100000

tenure = np.random.choice(
    [1,2,3,4],
    size=n,
    p=[0.2,0.3,0.4,0.1]
)

premium = tenure * 100

start_date = datetime(2024,1,1)
end_date = datetime(2024,12,31)

purchase_dates = pd.to_datetime(
    np.random.randint(
        start_date.timestamp(),
        end_date.timestamp(),
        n
    ),
    unit='s'
)

policy_start = purchase_dates + pd.Timedelta(days=365)

policy_end = policy_start + pd.to_timedelta(tenure*365, unit="D")

df_policy = pd.DataFrame({
    "Customer_ID": customer_id,
    "Vehicle_ID": vehicle_id,
    "Vehicle_Value": vehicle_value,
    "Policy_Tenure": tenure,
    "Premium": premium,
    "Policy_Purchase_Date": purchase_dates,
    "Policy_Start_Date": policy_start,
    "Policy_End_Date": policy_end
})

df_policy.to_csv("policy_sales_data.csv", index=False)

print("Policy dataset created!")

# ---------------------------
# Generate Claims Dataset
# ---------------------------

claims = []

claim_amount = 10000  # 10% of vehicle value

for index, row in df_policy.iterrows():
    
    purchase_day = row["Policy_Purchase_Date"].day
    
    # Claims in 2025 for specific purchase dates
    if purchase_day in [7, 14, 21, 28]:
        if np.random.rand() <= 0.30:  # 30% chance
            
            claims.append([
                row["Customer_ID"],
                row["Vehicle_ID"],
                claim_amount,
                row["Policy_Start_Date"],
                1
            ])

df_claims = pd.DataFrame(
    claims,
    columns=[
        "Customer_ID",
        "Vehicle_ID",
        "Claim_Amount",
        "Claim_Date",
        "Claim_Type"
    ]
)

df_claims["Claim_ID"] = range(1, len(df_claims) + 1)

# Save file
df_claims.to_csv("claims_data.csv", index=False)

print("Claims dataset created!")
# -------------------------
# ANALYSIS SECTION
# -------------------------

# Total premium collected in 2024
total_premium = df_policy["Premium"].sum()
print("\nTotal Premium Collected in 2024:", total_premium)


# Claim cost by year
df_claims["Year"] = pd.to_datetime(df_claims["Claim_Date"]).dt.year

claim_cost_year = df_claims.groupby("Year")["Claim_Amount"].sum()

print("\nClaim Cost by Year:")
print(claim_cost_year)


# Claim cost by month
df_claims["Month"] = pd.to_datetime(df_claims["Claim_Date"]).dt.month

claim_cost_month = df_claims.groupby(["Year","Month"])["Claim_Amount"].sum()

print("\nClaim Cost by Month:")
print(claim_cost_month)


# Claim ratio by policy tenure
merged = df_claims.merge(df_policy,on=["Customer_ID","Vehicle_ID"])

ratio = merged.groupby("Policy_Tenure")["Claim_Amount"].sum() / df_policy.groupby("Policy_Tenure")["Premium"].sum()

print("\nClaim Ratio by Policy Tenure:")
print(ratio)

import matplotlib.pyplot as plt

monthly = df_claims.groupby("Month")["Claim_Amount"].sum()

monthly.plot(kind="bar")

plt.title("Monthly Claim Trend")
plt.xlabel("Month")
plt.ylabel("Claim Amount")

plt.show()